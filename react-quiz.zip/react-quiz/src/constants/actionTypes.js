
export const ActionTypes = {
    QuizLoad: 'QuizLoad',
    QuizAnswer: 'QuizAnswer',
    QuizSubmit: 'QuizSubmit',
    PagerUpdate: 'PagerUpdate'
}